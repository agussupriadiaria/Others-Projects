import sys
import traceback

import bpy
from bpy.app.handlers import persistent, depsgraph_update_pre, depsgraph_update_post, load_pre, load_post, save_pre

from . import addon, insert, remove, update, smart

authoring_enabled = True
try: from . import matrixmath
except ImportError: authoring_enabled = False


def _check_main():
    '''This was legacy code designed to make KIT OPS free exit if there was a KIT OPS insert with no ID set.'''
    if not authoring_enabled:
        for obj in bpy.data.objects:
            if obj.kitops.main and not obj.kitops.id:
                print ('KIT OPS object is invalid state:')
                print ('KIT OPS object:', obj.name)
                print ('KIT OPS kitops.main:', obj.kitops.main)
                print ('KIT OPS kitops.id:', obj.kitops.id)
                # sys.exit() TODO re-introduce this if we absolutely have to.

# flag to determine whether we are saving or not.
is_saving = False
class pre:


    @persistent
    def depsgraph(none):

        global is_saving
        if is_saving:
            return

        if not insert.authoring():

            smart.insert_depsgraph_update_pre()

            insert.correct_ids()

        elif not authoring_enabled:
            for obj in bpy.data.objects:
                try:
                    obj.select_set(False)
                except RuntimeError: pass


        _check_main()


    @persistent
    def load(none):

        global is_saving
        if is_saving:
            return


        _check_main()


    @persistent
    def save(none):
        global is_saving
        if is_saving:
            return

        option = addon.option()

        if authoring_enabled:
            matrixmath.authoring_save_pre()

        _check_main()



class post:


    @persistent
    def depsgraph(none):
        global is_saving
        if is_saving:
            return

        preference = addon.preference()
        option = addon.option()

        if insert.authoring():
            if authoring_enabled:
                matrixmath.authoring_depsgraph_update_post()

        scene = bpy.context.scene

        if not insert.operator and scene and hasattr(scene, 'kitops') and scene.kitops and not scene.kitops.thumbnail:
            for obj in [ob for ob in bpy.data.objects if ob.kitops.duplicate]:
                remove.object(obj, data=True)

        if addon.preference().mode == 'SMART':
            insert.select()

        if not insert.operator:
            smart.toggles_depsgraph_update_post()

        _check_main()


        # enable inserts if in local view mode
        for area in bpy.context.screen.areas:
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    inserts = [i for i in insert.collect(all=True) if i.kitops.insert_target == bpy.context.active_object]
                    for target_insert in inserts:
                        if space.local_view:
                            target_insert.local_view_set(space, True)


    @persistent
    def load(none):
        global is_saving
        if is_saving:
            return
            
        option = addon.option()

        if insert.authoring():
            if authoring_enabled:
                matrixmath.authoring_load_post()
            else:
                for obj in bpy.data.objects:
                    obj.kitops.applied = True

        _check_main()


def register():
    depsgraph_update_pre.append(pre.depsgraph)
    depsgraph_update_post.append(post.depsgraph)
    load_pre.append(pre.load)
    load_post.append(post.load)
    save_pre.append(pre.save)


def unregister():
    depsgraph_update_pre.remove(pre.depsgraph)
    depsgraph_update_post.remove(post.depsgraph)
    load_pre.remove(pre.load)
    load_post.remove(post.load)
    save_pre.remove(pre.save)
