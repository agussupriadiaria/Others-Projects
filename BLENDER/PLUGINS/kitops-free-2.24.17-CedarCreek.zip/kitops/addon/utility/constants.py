# constant values
recently_used_limit = 5
favorites_limit = 15