import os

import bpy

from bpy.types import Operator
from bpy.props import *
from bpy.utils import register_class, unregister_class

from . import addon, bbox, id, insert, modifier, remove

#XXX: type and reference error
#DEPRECATED TODO this method now does nothing - remove if it works out ok.
def toggles_depsgraph_update_post():
    return
    option = addon.option()

    solid_inserts = insert.collect(solids=True, all=True)
    count = 0
    for obj in solid_inserts:
        try:
            if obj.hide_viewport:
                option['show_solid_objects'] = False
                break
            elif obj.name in bpy.context.view_layer.objects and not obj.select_get():
                count += 1
        except RuntimeError: pass

    if count > 2 and count == len(solid_inserts):
        option['show_solid_objects'] = True

    boolean_inserts = insert.collect(cutters=True, all=True)
    count = 0
    for obj in boolean_inserts:
        try:
            if obj.hide_viewport:
                option['show_cutter_objects'] = False
                break
            elif not obj.select_get():
                count += 1
        except RuntimeError: pass

    if count > 2 and count == len(boolean_inserts):
        option['show_cutter_objects'] = True

    wire_inserts = insert.collect(wires=True, all=True)
    count = 0
    for obj in wire_inserts:
        try:
            if obj.hide_viewport:
                option['show_wire_objects'] = False
                break
            elif not obj.select_get():
                count += 1
        except RuntimeError: pass

    if count > 2 and count == len(wire_inserts):
        option['show_wire_objects'] = True


def insert_depsgraph_update_pre():
    collected_objects = bpy.context.scene.collection.all_objects[:]

    if not hasattr(bpy.context, 'visible_objects'):
        return

    preference = addon.preference()

    if bpy.context.scene and not bpy.context.scene.kitops.thumbnail and preference.auto_remove_booleans:
        for obj in bpy.context.visible_objects:
            for mod in obj.modifiers:
                if mod.type != 'BOOLEAN':
                    continue

                if mod.object and mod.object.kitops.insert and mod.object not in collected_objects:
                    obj.modifiers.remove(mod)

            boolean_refs_to_remove = []
            for boolean_ref in obj.kitops.kitops_booleans:
                boolean_mod_name = boolean_ref.name
                if boolean_mod_name in obj.modifiers:
                    mod = obj.modifiers[boolean_mod_name]
                    if not mod.object:
                        obj.modifiers.remove(mod)
                else:
                    boolean_refs_to_remove.append(boolean_mod_name)
            for boolean_ref_to_remove in boolean_refs_to_remove:
                obj.kitops.kitops_booleans.remove(obj.kitops.kitops_booleans.find(boolean_ref_to_remove))
                pass


    objects = [obj for obj in collected_objects if not obj.kitops.insert and obj.type == 'MESH']
    inserts = [obj for obj in sorted(collected_objects, key=lambda o: o.name) if obj.kitops.insert]

    booleans_to_add = []
    for ins in inserts:
        if ins.kitops.type == 'CUTTER' and ins.kitops.insert_target:
            available = False
            for mod in ins.kitops.insert_target.modifiers:
                if mod.type == 'BOOLEAN' and mod.object == ins:
                    available = True
                    break

            if not available and ins.kitops.boolean_type != 'INSERT':
                # Only add if the object is a duplicate
                location_match = False
                for ins2 in inserts:
                    if ins.name != ins2.name and len(ins.data.vertices) == len(ins2.data.vertices) and ins.location == ins2.location:
                        insert.add_boolean(ins)
                        break
        
            
    # TODO Legacy code for reference to make sure we have not missed any logic.
    # for ins in inserts:
    #     if ins.kitops.type == 'CUTTER' and ins.kitops.insert_target:
    #         available = False
    #         for mod in ins.kitops.insert_target.modifiers:
    #             if mod.type == 'BOOLEAN' and mod.object == ins:
    #                 available = True

    #                 break

    #         if not available and ins.kitops.boolean_type != 'INSERT':
    #             print('Add Boolean?')
    #             insert.add_boolean(ins)

    #     if ins.kitops.type != 'CUTTER':
    #         continue

    #     for obj in objects:
    #         for mod in obj.modifiers:
    #             if mod.type != 'BOOLEAN':
    #                 continue

    #             if mod.object == obj and obj != obj.kitops.insert_target and obj.kitops.boolean_type != 'INSERT':
    #                 obj.modifiers.remove(mod)


def add_mirror(obj, axis='X'):
    obj.kitops.mirror = True
    mod = obj.modifiers.new(name='KIT OPS Mirror', type='MIRROR')

    if mod:
        mod.show_expanded = False
        mod.use_axis[0] = False

        index = {'X': 0, 'Y': 1, 'Z': 2} # patch inplace for api change
        axis_to_use = getattr(obj.kitops, F'mirror_{axis.lower()}')
        mod.use_axis[index[axis]] = axis_to_use


        mod.mirror_object = obj.kitops.insert_target
        obj.kitops.mirror_target = obj.kitops.insert_target

        sort_modifiers(obj)




def validate_mirror(inserts, axis='X'):
    for obj in inserts:
        if obj.kitops.mirror:

            available = False
            # assuming our mirror is most recent
            for modifier in reversed(obj.modifiers):

                if modifier.type == 'MIRROR' and modifier.mirror_object == obj.kitops.mirror_target:
                    available = True
                    index = {'X': 0, 'Y': 1, 'Z': 2} # patch inplace for api change
                    axis_to_use = getattr(obj.kitops, F'mirror_{axis.lower()}')
                    modifier.use_axis[index[axis]] = axis_to_use


                    if True not in modifier.use_axis[:]:
                        obj.kitops.mirror = False
                        obj.kitops.mirror_target = None
                        obj.modifiers.remove(modifier)

                    break

            if not available:
                add_mirror(obj, axis=axis)

        else:
            add_mirror(obj, axis=axis)


def sort_modifiers(obj):

    array_mod_index = obj.modifiers.find('KIT OPS Array')
    mirror_mod_index = obj.modifiers.find('KIT OPS Mirror')
    while (array_mod_index != -1 and mirror_mod_index != -1 and mirror_mod_index < array_mod_index):
        bpy.ops.object.modifier_move_down({'object': obj}, modifier='KIT OPS Mirror')
        array_mod_index = obj.modifiers.find('KIT OPS Array')
        mirror_mod_index = obj.modifiers.find('KIT OPS Mirror')


def update_array(obj, mod):
    if mod:
        mod.show_expanded = False
        mod.count = obj.kitops.array_count
        mod.use_relative_offset = False
        mod.use_constant_offset = True
        mod.constant_offset_displace = obj.kitops.array_offset

def add_array(obj):

    if obj.kitops.array_count > 1:
        mod = obj.modifiers.new(name='KIT OPS Array', type='ARRAY')
        update_array(obj, mod)

        sort_modifiers(obj)

def validate_array(inserts):


    for obj in inserts:
        # assuming our mirror is most recent
        available = False
        for modifier in reversed(obj.modifiers):            
            if modifier.type == 'ARRAY' and modifier.name.startswith('KIT OPS Array'):
                available = True

                # update the array modifier.
                if obj.kitops.array_count <= 1:
                    obj.modifiers.remove(modifier)
                else:
                    update_array(obj, modifier)
                break

        if not available:
            add_array(obj)


# XXX: align needs to check dimensions with current insert disabled
class KO_OT_align_horizontal(Operator):
    bl_idname = 'ko.align_horizontal'
    bl_label = 'Align horizontal'
    bl_description = 'Align selected INSERTS horizontally within target bounds'
    bl_options = {'REGISTER', 'UNDO'}

    y_axis: BoolProperty(
        name = 'Y Axis',
        description = 'Use the y axis of the INSERT TARGET for alignment',
        default = False)

    def execute(self, context):

        # get mains
        mains = insert.collect(context.selected_objects, mains=True)

        for main in mains:
            if main.kitops.insert_target:
                center = bbox.center(main.kitops.insert_target)
                setattr(main.location, 'y' if self.y_axis else 'x', getattr(center, 'y' if self.y_axis else 'x'))

        return {'FINISHED'}


class KO_OT_align_vertical(Operator):
    bl_idname = 'ko.align_vertical'
    bl_label = 'Align vertical'
    bl_description = 'Align selected INSERTS vertically within target bounds'
    bl_options = {'REGISTER', 'UNDO'}

    z_axis: BoolProperty(
        name = 'Z Axis',
        description = 'Use the Z axis of the INSERT TARGET for alignment',
        default = False)

    def execute(self, context):

        # get mains
        mains = insert.collect(context.selected_objects, mains=True)

        for main in mains:
            if main.kitops.insert_target:
                center = bbox.center(main.kitops.insert_target)
                setattr(main.location, 'z' if self.z_axis else 'y', getattr(center, 'z' if self.z_axis else 'y'))

        return {'FINISHED'}


class KO_OT_align_left(Operator):
    bl_idname = 'ko.align_left'
    bl_label = 'Align left'
    bl_description = 'Align selected INSERTS to the left of the target bounds'
    bl_options = {'REGISTER', 'UNDO'}

    y_axis: BoolProperty(
        name = 'Y Axis',
        description = 'Use the y axis of the INSERT TARGET for alignment',
        default = False)

    def execute(self, context):

        mains = insert.collect(context.selected_objects, mains=True)

        for main in mains:
            if main.kitops.insert_target:
                left = bbox.back(main.kitops.insert_target).y if self.y_axis else bbox.left(main.kitops.insert_target).x
                setattr(main.location, 'y' if self.y_axis else 'x', left)

        return {'FINISHED'}


class KO_OT_align_right(Operator):
    bl_idname = 'ko.align_right'
    bl_label = 'Align right'
    bl_description = 'Align selected INSERTS to the right of the target bounds'
    bl_options = {'REGISTER', 'UNDO'}

    y_axis: BoolProperty(
        name = 'Y Axis',
        description = 'Use the y axis of the INSERT TARGET for alignment',
        default = False)

    def execute(self, context):

        mains = insert.collect(context.selected_objects, mains=True)

        for main in mains:
            if main.kitops.insert_target:
                right = bbox.front(main.kitops.insert_target).y if self.y_axis else bbox.right(main.kitops.insert_target).x
                setattr(main.location, 'y' if self.y_axis else 'x', right)

        return {'FINISHED'}


class KO_OT_align_top(Operator):
    bl_idname = 'ko.align_top'
    bl_label = 'Align top'
    bl_description = 'Align selected INSERTS to the top of the target bounds'
    bl_options = {'REGISTER', 'UNDO'}

    z_axis: BoolProperty(
        name = 'Z Axis',
        description = 'Use the Z axis of the INSERT TARGET for alignment',
        default = False)

    def execute(self, context):

        mains = insert.collect(context.selected_objects, mains=True)

        for main in mains:
            if main.kitops.insert_target:
                top = bbox.top(main.kitops.insert_target).z if self.z_axis else bbox.back(main.kitops.insert_target).y
                setattr(main.location, 'z' if self.z_axis else 'y', top)

        return {'FINISHED'}


class KO_OT_align_bottom(Operator):
    bl_idname = 'ko.align_bottom'
    bl_label = 'Align bottom'
    bl_description = 'Align selected INSERTS to the bottom of the target bounds'
    bl_options = {'REGISTER', 'UNDO'}

    z_axis: BoolProperty(
        name = 'Z Axis',
        description = 'Use the Z axis of the INSERT TARGET for alignment',
        default = False)

    def execute(self, context):

        mains = insert.collect(context.selected_objects, mains=True)

        for main in mains:
            if main.kitops.insert_target:
                bottom = bbox.bottom(main.kitops.insert_target).z if self.z_axis else bbox.front(main.kitops.insert_target).y
                setattr(main.location, 'z' if self.z_axis else 'y', bottom)

        return {'FINISHED'}


class KO_OT_stretch_wide(Operator):
    bl_idname = 'ko.stretch_wide'
    bl_label = 'Stretch wide'
    bl_description = 'Stretch selected INSERTS to the width of the target bounds'
    bl_options = {'REGISTER', 'UNDO'}

    y_axis: BoolProperty(
        name = 'X axis',
        description = 'Use the Y axis of the INSERT TARGET for stretching',
        default = False)

    halve: BoolProperty(
        name = 'Halve',
        description = 'Halve the stretch amount',
        default = False)

    def execute(self, context):

        mains = insert.collect(context.selected_objects, mains=True)

        for main in mains:
            if main.kitops.insert_target:
                dimension = main.kitops.insert_target.dimensions[1 if self.y_axis else 0]

                if self.halve:
                    dimension /= 2

                main.scale.x = dimension / main.dimensions[0] * main.scale.x

        return {'FINISHED'}


class KO_OT_stretch_tall(Operator):
    bl_idname = 'ko.stretch_tall'
    bl_label = 'Stretch tall'
    bl_description = 'Stretch selected INSERTS to the height of the target bounds'
    bl_options = {'REGISTER', 'UNDO'}

    z_axis: BoolProperty(
        name = 'Side',
        description = 'Use the Z axis of the INSERT TARGET for stretching',
        default = False)

    halve: BoolProperty(
        name = 'Halve',
        description = 'Halve the stretch amount',
        default = False)

    def execute(self, context):

        mains = insert.collect(context.selected_objects, mains=True)

        for main in mains:
            if main.kitops.insert_target:
                dimension = main.kitops.insert_target.dimensions[2 if self.z_axis else 1]

                if self.halve:
                    dimension /= 2

                main.scale.y = dimension / main.dimensions[1] * main.scale.y

        return {'FINISHED'}



smart_update = True
class update:


    def main(prop, context):
        global smart_update
        if not smart_update:
            return
        smart_update = False
        try:
            for obj in bpy.data.objects:
                if obj != context.active_object:
                    obj.kitops.main = False
                else:
                    obj.kitops.main = True

        finally:
            smart_update = True

    def insert_target(prop, context):
        global smart_update
        if not smart_update:
            return
        smart_update = False
        try:
            inserts = insert.collect(context.selected_objects)

            for obj in inserts:
                if not context.active_object:
                    continue
                obj.kitops.applied = False

                if obj.kitops.insert_target:
                    obj.kitops.reserved_target = context.active_object.kitops.insert_target
        finally:
            smart_update = True

    def mirror_x(prop, context):
        global smart_update
        if not smart_update:
            return
        smart_update = False
        try:
            inserts = insert.collect(context.selected_objects)

            for obj in inserts:
                obj.kitops.mirror_x = bpy.context.active_object.kitops.mirror_x

            validate_mirror(inserts, axis='X')
        finally:
            smart_update = True

    def mirror_y(prop, context):
        global smart_update
        if not smart_update:
            return
        smart_update = False
        try:
            inserts = insert.collect(context.selected_objects)

            for obj in inserts:
                obj.kitops.mirror_y = bpy.context.active_object.kitops.mirror_y

            validate_mirror(inserts, axis='Y')
        finally:
            smart_update = True

    def mirror_z(prop, context):
        global smart_update
        if not smart_update:
            return
        smart_update = False
        try:  
            inserts = insert.collect(context.selected_objects)

            for obj in inserts:
                obj.kitops.mirror_z = bpy.context.active_object.kitops.mirror_z

            validate_mirror(inserts, axis='Z')
        finally:
            smart_update = True

    def array_insert(prop, context):
        global smart_update
        if not smart_update:
            return
        smart_update = False
        try:
            inserts = insert.collect(context.selected_objects)

            for obj in inserts:
                obj.kitops.array_count = bpy.context.active_object.kitops.array_count
                obj.kitops.array_offset = bpy.context.active_object.kitops.array_offset

            validate_array(inserts)
        finally:
            smart_update = True


        return None

classes = [
    KO_OT_align_horizontal,
    KO_OT_align_vertical,
    KO_OT_align_left,
    KO_OT_align_right,
    KO_OT_align_top,
    KO_OT_align_bottom,
    KO_OT_stretch_wide,
    KO_OT_stretch_tall]


def register():
    for cls in classes:
        register_class(cls)


def unregister():
    for cls in classes:
        unregister_class(cls)
